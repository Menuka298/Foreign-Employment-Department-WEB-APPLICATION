﻿using ComplainsAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace ComplainsAPI.DataAccess
{
    public class ComplaintDbContext :DbContext
    {
        public ComplaintDbContext(DbContextOptions<ComplaintDbContext> options) : base(options)
        {

        }
        public DbSet<Complaint> Complains { get; set; }

        public DbSet<User> users { get; set; }


    }
}
