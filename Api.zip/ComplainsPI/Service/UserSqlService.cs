﻿using ComplainsAPI.DataAccess;
using ComplainsAPI.Models;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace ComplainsAPI.Service
{
    public class UserSqlService : IUserRepository
    {
        readonly ComplaintDbContext _complaintDbContext;
        public UserSqlService(ComplaintDbContext complaintDbContext)
        {
            _complaintDbContext = complaintDbContext;
        }
        public User GetUserByNic(string nic,string password)
        {
            try
            {

                var result = _complaintDbContext.users.Where(x => x.NIC == nic).FirstOrDefault();
                if(result != null)
                {
                    System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                    System.Text.Decoder utf8Decode = encoder.GetDecoder();
                    byte[] todecode_byte = Convert.FromBase64String(result.Password);
                    int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                    char[] decoded_char = new char[charCount];
                    utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                    string decodePassword = new String(decoded_char);
                    if (decodePassword == password)
                    {
                        return result;
                    }
                    else
                    {
                        return null;
                    }
                }
               
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
           
        }

        public User GetUSerByUeserName(string username,string password)
        {
            try
            {
                var result = _complaintDbContext.users.Where(x => x.UserName == username).FirstOrDefault();
                if(result != null)
                {
                    result.Token = result.Password;
                    System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                    System.Text.Decoder utf8Decode = encoder.GetDecoder();
                    byte[] todecode_byte = Convert.FromBase64String(result.Password);
                    int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                    char[] decoded_char = new char[charCount];
                    utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                    string decodePassword = new String(decoded_char);
                    if (decodePassword == password)
                    {
                        return result;
                    }
                    else
                    {
                        return null;
                    } 
                    
                }
                return result;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public User RegisterAdmin(User admin)
        {
           
            byte[] encData_byte = new byte[admin.Password.Length];
            encData_byte = System.Text.Encoding.UTF8.GetBytes(admin.Password);
            string encodedData = Convert.ToBase64String(encData_byte);
            admin.Password = encodedData;
            admin.UserType = 1;
            _complaintDbContext.users.Add(admin);
            _complaintDbContext.SaveChanges();
            return admin;
        }

        public User RegisterNormalUser(User user)
        {

            byte[] encData_byte = new byte[user.Password.Length];
            encData_byte = System.Text.Encoding.UTF8.GetBytes(user.Password);
            string encodedData = Convert.ToBase64String(encData_byte);
            user.Password = encodedData;
            //user.UserType = 1;
            _complaintDbContext.users.Add(user);
            _complaintDbContext.SaveChanges();
            return user;
        }
    }
}
