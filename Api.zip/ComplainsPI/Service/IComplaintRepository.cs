﻿using ComplainsAPI.Models;

namespace ComplainsAPI.Service
{
    public interface IComplaintRepository
    {
        public Complaint GetComplaint(int id);
        public Complaint Savecomplaint();
        public List<Complaint> GetAllComplaints();
        public Complaint SaveComplaints(Complaint complaint);
        public int GetComplaintCount();
        public int GetComplaintCheckedCount();
        public Complaint ChangeComplaintStatus(int id);
        public Complaint UndoComplaintStatus(int id);
    }
}
