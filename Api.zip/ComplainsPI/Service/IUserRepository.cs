﻿using ComplainsAPI.Models;

namespace ComplainsAPI.Service
{
    public interface IUserRepository
    {
        public User GetUSerByUeserName(string username, string password);

        public User GetUserByNic(string nic, string password);

        public User RegisterNormalUser(User user);

        public User RegisterAdmin(User user);
    }
}
