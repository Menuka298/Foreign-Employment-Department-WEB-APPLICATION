﻿using ComplainsAPI.DataAccess;
using ComplainsAPI.Models;

namespace ComplainsAPI.Service
{
    public class ComplaintSqlService : IComplaintRepository
    {
        readonly ComplaintDbContext _complaintDbContext;

        public ComplaintSqlService(ComplaintDbContext complainDbContext)
        {
            _complaintDbContext = complainDbContext;
        }

        public Complaint Savecomplaint()
        {
            throw new NotImplementedException();
        }

        public List<Complaint> GetAllComplaints()
        {
           return _complaintDbContext.Complains.ToList();
        }

        public Complaint GetComplaint(int id)
        {
            return _complaintDbContext.Complains.Where(x => x.Id == id).FirstOrDefault();
            
        }

        public Complaint SaveComplaints(Complaint complaint)
        {
           
          _complaintDbContext.Complains.Add(complaint);
            _complaintDbContext.SaveChanges();
            return complaint;
        }

        public int GetComplaintCount()
        {
           return  _complaintDbContext.Complains.ToList().Count;
        }

        public int GetComplaintCheckedCount()
        {
            return _complaintDbContext.Complains.Where(x => x.ComplainType == 1).ToList().Count;
        }

        public Complaint ChangeComplaintStatus(int id)
        {
            var existingComplaint= _complaintDbContext.Complains.Where(s => s.Id == id)
                                                   .FirstOrDefault();
            if(existingComplaint != null)
            {
                existingComplaint.ComplainType = 1;
            }
            _complaintDbContext.SaveChanges();

            return existingComplaint;
        }

        public Complaint UndoComplaintStatus(int id)
        {
            var existingComplaint = _complaintDbContext.Complains.Where(s => s.Id == id)
                                                   .FirstOrDefault();
            if (existingComplaint != null)
            {
                existingComplaint.ComplainType = 0;
            }
            _complaintDbContext.SaveChanges();

            return existingComplaint;
        }
    }
}
