﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ComplainsAPI.Models
{
    public class User
    {
        public int Id { get; set; }
      
        public int UserType { get; set; }

        [MaxLength(20)]
        [Required]
        public string UserName { get; set; }

        [MaxLength(100)]
        public string FullName { get; set; }

        [MaxLength(20)]
        public string ContactNo { get; set; }

        [MaxLength(20)]
        
        public string NIC { get; set; }

        [Required]
        public string Password { get; set; }

        [MaxLength(100)]
        public string Email { get; set; }
        public DateTime RegisterDate { get; set; } = DateTime.Now;

        [NotMapped]
        public string Token { get; set; }


    }
}
