﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ComplainsAPI.Models
{
    public class Complaint
    {
       
        public int Id { get; set; }
        [MaxLength(50)]
        public string country { get; set; }
        [MaxLength(60)]
        public string fullname { get; set; }
        [MaxLength(500)]
        public string Catagory { get; set; }
        [MaxLength(200)]
        public string lastname { get; set; }
        [MaxLength(60)]
        public string Email { get; set; }
        [MaxLength(100)]
        public string Address { get; set;}

        public string Jobname { get; set; }
        [MaxLength(60)]

        public string Agencyname { get; set; }
        [MaxLength(60)]

        public string age { get; set; }
        [MaxLength(60)]

        public string Attachment { get; set; }

        [NotMapped]
        public IFormFile Attachmentfile { get; set; }
        public int ComplainType { get; set; } = 0;

        [MaxLength(100)]
        public string Nic { get; set; }
        [MaxLength(10)]
        public string passportnumber { get; set; }
        [MaxLength(15)]
        public string ContactNo { get; set; }
        public DateTime date { get; set; } = DateTime.Now;
        public string Complaint { get; set; }

    }
}
