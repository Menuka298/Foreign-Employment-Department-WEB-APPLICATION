﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ComplainsAPI.Migrations
{
    public partial class newfeildstoUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ContactNo",
                table: "users",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FullName",
                table: "users",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ContactNo",
                table: "users");

            migrationBuilder.DropColumn(
                name: "FullName",
                table: "users");
        }
    }
}
