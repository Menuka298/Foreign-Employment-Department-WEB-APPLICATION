﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ComplainsAPI.Migrations
{
    public partial class ChangeCompalintsmodel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DrivingLicence",
                table: "Complains",
                newName: "Nic");

            migrationBuilder.AddColumn<string>(
                name: "NormalComplaint",
                table: "Complains",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NormalComplaint",
                table: "Complains");

            migrationBuilder.RenameColumn(
                name: "Nic",
                table: "Complains",
                newName: "DrivingLicence");
        }
    }
}
