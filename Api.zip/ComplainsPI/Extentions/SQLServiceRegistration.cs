﻿using ComplainsAPI.DataAccess;
using ComplainsAPI.Service;
using Microsoft.EntityFrameworkCore;

namespace ComplainsAPI.Extentions
{
    public static class SQLServiceRegistration
    {
        public static void AddComplaintDBContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<ComplaintDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("ComplaintDBCon"));
            });

            services.AddScoped<IComplaintRepository, ComplaintSqlService>();
            services.AddScoped<IUserRepository, UserSqlService>();


        }
    }
}
