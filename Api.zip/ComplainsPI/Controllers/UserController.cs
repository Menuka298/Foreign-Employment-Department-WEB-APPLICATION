﻿using ComplainsAPI.Models;
using ComplainsAPI.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ComplainsAPI.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        //**Get User By UserName**//
        [HttpGet("GetUserByUserName/{username}/{password}")]
        public IActionResult GetUserByUserName(string username,string password)
        {
            var result = _userRepository.GetUSerByUeserName(username.Trim(),password);
            if(result != null)
            {
                return Ok(result);
            }
            else
            {
                return NoContent();
            }
           
        }

        //**Get User By Nic**//
        [HttpGet("GetUserByNic/{nic}/{password}")]
        public IActionResult GetUserByNic(string nic,string password)
        {
            var result = _userRepository.GetUserByNic(nic.Trim(),password.Trim());
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return NoContent();
            }
        }

        //**Register Admin**//
        [HttpPost("RegisterAdmin")]
        public IActionResult RegisterAdmin(User admin)
        {
            if(admin.Password != null && admin.UserName != null)
            {
                var result = _userRepository.RegisterAdmin(admin);
                return Ok(result);
            }
            else
            {
                return NoContent();
            }
        }

        //**Register User**//
        [HttpPost("RegisterUser")]
        public IActionResult RegisterUser(User user)
        {
            if (user.Password != null && user.UserName != null)
            {
                var result = _userRepository.RegisterNormalUser(user);
                return Ok(result);
            }
            else
            {
                return NoContent();
            }
        }
    }
}
