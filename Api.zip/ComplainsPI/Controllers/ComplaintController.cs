﻿using ComplainsAPI.Models;
using ComplainsAPI.Service;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ComplainsAPI.Controllers
{
    [Route("api/Complaints")]
    [ApiController]
    public class ComplaintController : ControllerBase
    {
        private readonly IComplaintRepository _complainRepository;

        private readonly IWebHostEnvironment _WebHostEnvironment;

        public ComplaintController(IComplaintRepository complainRepository,IWebHostEnvironment  webHostEnvironment)
        {
            _complainRepository = complainRepository;
            _WebHostEnvironment = webHostEnvironment;
        }
        
        //**Get All complaints**//
        [HttpGet]
        public IActionResult GetComplaints()
        {
            var complains = _complainRepository.GetAllComplaints();  
            return Ok(complains);
        }

        //**Get one complaint**//
        [HttpGet("{id}",Name = "GetComplaint")]
        public IActionResult GetComplaintsById(int id)
        {
            var complaint = _complainRepository.GetComplaint(id);
            if(complaint is null)
            {
                return NotFound();
            }
            else
            {
                return Ok(complaint);
            }           
        }

        //**Add Complaint**//
        [HttpPost]
        public IActionResult CreateComplaint([FromForm]Complaint complaint)
        {
                        
            if (complaint.Name is not null)
            {
                if(complaint.Attachmentfile != null)
                {
                    complaint.Attachment = SaveAttachment(complaint.Attachmentfile);
                }               
                _complainRepository.SaveComplaints(complaint);
                return CreatedAtRoute("GetComplaint", new { id = complaint.Id }, complaint);
            }
            else
            {
                return NoContent();
            }
        }

        [NonAction]
        public string SaveAttachment(IFormFile imagefile)
        {
            if (imagefile != null)
            {
                string imagename = imagefile.FileName;
                imagename = imagename +DateTime.Now.ToString("yymmssfff") + Path.GetExtension(imagefile.FileName);
                var imagepath = Path.Combine(_WebHostEnvironment.ContentRootPath, "Attachments", imagename);
                using (var fs = new FileStream(imagepath, FileMode.Create))
                {
                    imagefile.CopyTo(fs);
                }
                return imagename;
            }
            else
            {
                return null;
            }

        }

        //**Get All complaints count**//
        [HttpGet("GetComplaintsCount")]
        public IActionResult GetComplaintsCount()
        {
            var complains = _complainRepository.GetComplaintCount();
            return Ok(complains);
        }

        //**Get All complaints Checked count**//
        [HttpGet("GetComplaintsCheckedCount")]
        public IActionResult GetComplaintsCheckedCount()
        {
            var complains = _complainRepository.GetComplaintCheckedCount();
            return Ok(complains);
        }

        //**Update complaints Status**//
        [HttpPut("{id}")]
        public IActionResult UpdateComplaintStatus(int id)
        {
            var result = _complainRepository.ChangeComplaintStatus(id);
            if ( result!= null)
            {
                return Ok(result);
            }
            else
            {
                return NotFound();
            }
        }

        //**Undo complaints Status**//
        [HttpPut("UndoComplaintStatus/{id}")]
        public IActionResult UndoComplaintStatus(int id)
        {
            var result = _complainRepository.UndoComplaintStatus(id);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return NotFound();
            }
        }




    }
}
