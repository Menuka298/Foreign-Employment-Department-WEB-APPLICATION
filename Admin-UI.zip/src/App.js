import React from "react";
import "./assets/css/bootstrap.min.css";
import Main from "./components/Main/Main";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NormalComplaintList from "./components/Complaints/NormalComplaintList";
import LoginPage from "./components/Login/LoginPage";
import ViewNormalComplaint from "./components/Complaints/ViewNormalComplaint"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />}></Route>
        <Route path="/Main" element={<Main />}></Route>
        <Route path="/NormalComplaintList" element={<NormalComplaintList />}></Route>
        <Route path="/ViewNormalComplaint/:id" element={<ViewNormalComplaint />}></Route> 
      </Routes>
    </BrowserRouter>
  );
}

export default App;
