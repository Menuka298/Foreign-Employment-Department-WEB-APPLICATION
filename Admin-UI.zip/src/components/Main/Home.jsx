import React, { Component } from "react";
import axios from "axios";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      NormalComolaintCount: 0,
      NormalCheckedCount: 0,
    };
  }

  componentDidMount = () => {

    const config = localStorage.getItem('token');
    if(config === null)
    {
      window.location.href = "/";
    }

    axios
      .get("https://localhost:7257/api/Complaints/GetComplaintsCount",config)
      .then((response) => {
        this.setState({ NormalComolaintCount: response.data });
      })
      .catch(function(error) {
        console.log(error);
      });

    axios
      .get("https://localhost:7257/api/Complaints/GetComplaintsCheckedCount")
      .then((response) => {
        this.setState({ NormalCheckedCount: response.data });
      })
      .catch(function(error) {
        console.log(error);
      });
  };

  render() {
    return (
      <div>
        <div className="row">
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">Complaints</h5>
                {/* <p className="card-text">
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </p> */}
                <div className="row">
                  <div className="col-md-6">
                    <a href="#" className="btn btn-primary">
                      Total :{this.state.NormalComolaintCount}
                    </a>
                  </div>
                  <div className="col-md-6">
                    <a href="#" className="btn btn-dark">
                      Checked :{this.state.NormalCheckedCount}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
