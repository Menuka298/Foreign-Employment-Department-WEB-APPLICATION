import React, { Component } from "react";
import { Link } from "react-router-dom";
import "../../assets/css/CustomCSS/SideNavigation.css";
import "../../assets/js/SideNavigation.js";
import logo from "../../../src/assets/images/logo.jpg";

class SideNavigation extends Component {
  render() {
    return (
      <nav id="sidebar">
        <div className="sidebar-header">
          <img src={logo} alt="logo" />
        </div>

        <ul className="list-unstyled components">
          <li className="active">
            <Link to="/Main">
              <i className="bi bi-house-fill"></i>
              <span style={{ paddingLeft: 5 }}>Home</span>
            </Link>
          </li>
          <li>
            <a
              href="#StudentSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
              className="dropdown-toggle"
            >
              <i class="bi bi-briefcase-fill"></i>
              <span style={{ paddingLeft: 5 }}> Complaints</span>
            </a>
            <ul className="collapse list-unstyled" id="StudentSubmenu">
              <li>
                <Link to="/NormalComplaintList">
                  <i class="bi bi-arrow-right-circle-fill"></i>
                  <span style={{ paddingLeft: 5 }}> Complaints</span>
                </Link>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    );
  }
}

export default SideNavigation;
