/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import logo from "../../../src/assets/images/logo.jpg"
import "./Home.css";

export default function homepage() {
  return (

    
    <div className="Login">
      
      <div className="d-flex justify-content-center">
            <img
              src={logo}
              alt="logo"
              className="card-img-top"
              style={{ height: 300, width: 1400 }}
            />
          </div>
    </div>
  );
}
