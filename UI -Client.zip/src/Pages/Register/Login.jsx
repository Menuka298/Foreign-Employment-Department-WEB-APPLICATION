import React from "react";
import axios from "axios";

class Login extends React.Component {
  state = { nic: "", password: "" };

  btnSignin = (e) => {

    axios
      .get(
        "" +
          this.state.nic +
          "/" +
          this.state.password
      )
      .then((response) => {
        //console.log(response);
        if (response.status == 200) {
          window.location.href = "MainPage";
        } else {
          alert("Incorrect Password or NIC.Please check!");
        }
      })
      .catch(function(error) {
        console.log(error);
      });
  };

  btnSignup = (e) => {
    //console.log(this.state);
    window.location.href = "/Register";
    
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  render() {
    return (
      <div className="col-md-3" style={{ marginLeft: 500, marginTop: 50 }}>
        <form>
          <div className="d-flex justify-content-center">
          </div>

          <div className="d-flex justify-content-center">
            <h1>Login</h1>
          </div>
          <div className="mb-3">
            <input
              type="email"
              className="form-control"
              id="nic"
              placeholder="NIC OR Passport Number"
              name="nic"
              onChange={this.handleChange}
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              className="form-control"
              id="password"
              placeholder="password"
              name="password"
              onChange={this.handleChange}
            />
          </div>
          <div className="row" style={{paddingLeft:45}}>
          <button
            type="button"
            className="btn btn-primary btn-lg btn-block"
            onClick={this.btnSignin}
            
          >
            Sign in
          </button>       
          <button
            type="button"
            className="btn btn-secondary btn-lg btn-block"
            onClick={this.btnSignup}
          >
            Sign Up
          </button>
          </div>         
        </form>
      </div>
    );
  }
}

export default Login;
