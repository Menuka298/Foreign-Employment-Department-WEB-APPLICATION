import React from "react";
import axios from "axios";

//class LoginPage extends React.Component
class Signup extends React.Component {
  state = {
    firstname: "",
    lastname: "",
    username: "",
    email: "",
    age: "",
    birthday: "",
    nic: "",
    country: "",
    jobname: "",
    password: "",
    agencyname: "",
    passportnumber: "",
    usertype: 2,
    contactNo: "",
    retypepassword: "",
  };
  btnClickRegister = (e) => {
    if (this.state.password != this.state.retypepassword) {
      alert("Password mismatch!Please check again.");
    } else {
      axios
        .post("", {
          userType: 2,
          userName: this.state.username,
          firstName: this.state.firstname,
          lastName: this.state.lastname,
          contactNo: this.state.contactNo,
          nic: this.state.nic,
          password: this.state.password,
          agencyname: this.state.agencyname,
          passportnumber: this.state.passportnumber,
          age: this.state.age,
          birthday: this.state.birthday,
          jobname: this.state.jobname,
          email: this.state.email,
        })
        .then(function (response) {
          //console.log(response);
          if (response.status == 200) {
            alert("Registerd Successfully.");
            window.location.href = "/Login";
          } else {
            alert("Registration issue.");
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }

    console.log(this.state);
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  render() {
    return (
      <div>
        <br />

        <div className="container col-md-6">
          <h2>REGISTER</h2>
          <form
            className="form-control"
            action=""
          >
            <input
              className="form-control"
              type="text"
              placeholder="First Name"
              required
              name="firstname"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Last Name"
              required
              name="lastname"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Contact Number"
              required
              name="contactNo"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Email"
              required
              name="email"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="NIC"
              required
              name="nic"
              onChange={this.handleChange}
            />
            <br></br>

            <input
              className="form-control"
              type="text"
              placeholder="Birthday"
              required
              name="Birthday"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="age"
              required
              name="age"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Agency Name"
              required
              name="agencyname"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Passport Number"
              required
              name="passportnumber"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="text"
              placeholder="Job Name"
              required
              name="jobname"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="password"
              placeholder="Password"
              required
              name="password"
              onChange={this.handleChange}
            />
            <br></br>
            <input
              className="form-control"
              type="password"
              placeholder="ReType-Password"
              required
              name="retypepassword"
              onChange={this.handleChange}
            />
            <br />
            <div className="btn-toolbar">
              <button
                type="submit"
                className="btn btn-success ml-6"
                onClick={this.btnClickRegister}
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Signup;
