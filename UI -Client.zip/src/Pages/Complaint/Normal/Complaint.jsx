/* eslint-disable no-unused-expressions */
import React, { Component, useState, useEffect } from "react";
import "./Complaint.css";
import axios from "axios";

export default class complaint extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Firstname: "",
      lastname: "",
      Country: "",
      Jobname: "",
      Agencyname: "",
      Passportnumber: "",
      Catagory: "",
      Email: "",
      Address: "",
      ComplainType: 0,
      ContactNo: "",
      NIC: "",
      Complaint: "",
    };
  }

  ChangeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  ChangeHandlerImage = (e) => {
    this.setState({ Attachmentfile: e.target.files[0] });
  };

  OnCreateComplaint = (event) => {
    event.preventDefault();
    const formData = new FormData();

    const _Complaint = {
      Firstname: this.state.Firstname,
      lastname: this.state.lastname,
      Country: this.state.Country,
      Jobname: this.state.Jobname,
      Agencyname: this.state.Agencyname,
      Passportnumber:this.state.Passportnumber,
      Catagory: this.state.Catagory,
      Email: this.state.Email,
      Address: this.state.Address,
      ContactNo: this.state.ContactNo,
      NIC: this.state.NIC,
      Name: this.state.Name,
      Complaint: this.state.Complaint,
    };

    formData.append("Firstname", this.state.Firstname),
    formData.append("lastname", this.state.lastname),
    formData.append("Country", this.state.Country),
    formData.append ("Jobname", this.state.Jobname),
    formData.append ("Agencyname", this.state.Agencyname),
    formData.append ("Passportnumber",this.state.Passportnumber),
    formData.append ("Catagory", this.state.Catagory),
    formData.append ("Email", this.state.Email),
    formData.append ("Address", this.state.Address),
    formData.append ("ContactNo", this.state.ContactNo),
    formData.append ("NIC", this.state.NIC),
    formData.append ("Name", this.state.Name),
    formData.append ("Complaint", this.state.Complaint),
    console.log(this.state);

    axios({
      method: "post",
      url: "",
      data: formData,
      headers: {
        "Content-Type": "multipart/form-data; boundary=${form._boundary}",
        Accept: "*/*",
      },
    })
      .then(function (response) {
        console.log(response);
        if (response.status == 201) {
          alert("Successfully Saved");
          window.location.reload(false);
        }
      })
      .catch(function (response) {
        console.log(response);
        if (response.status == 500) {
          alert("Internal Server Error");
        } else if (response.status == 500) {
          alert("Bad Request");
        }
      });

  };

  render() {
    const {
      Firstname,
      lastname,
      Country,
      Jobname ,
      Agencyname ,
      Passportnumber ,
      Catagory ,
      Email ,
      Address ,
      ComplainType ,
      ContactNo ,
    } = this.state;
    return (
      <div className="form">
        <div>
          <form method="POST" onSubmit={this.OnCreateComplaint}>
            <div className="row">
              <div className="col-md-6">
                <label className="form-label">
                   (Select your Country)
                </label>
                <select
                  className="form-control"
                  required
                  name="Country"

                  onChange={this.ChangeHandler}
                >
                  <option defaultValue="Srilanka">Kandy</option>
                  <option>india</option>
                </select>
                <br></br>
                <label className="form-label">
                  Select Your Complain Catageroy
                </label>
                <select
                  className="form-control"
                  name="Catagory"

                  onChange={this.ChangeHandler}
                >
                  <option>Abuse of Women Or Children</option>
                  <option> Accident</option>
                  <option>Robbery</option>
                </select>
                <br></br>
                <label className="form-label">
                   (Enter Your First Name){" "}
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="Name"

                  placeholder="Full name"
                  required
                  onChange={this.ChangeHandler}
                />

                <br></br>
                <label className="form-label">
                   (Enter Your Last Name){" "}
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="lastname"

                  placeholder="Full Name"
                  required
                  onChange={this.ChangeHandler}
                />

                <br />
                <label className="form-label">
                   (Enter Your Telephone Number){" "}
                </label>
                <input
                  className="form-control"
                  name="ContactNo"
                  type="text"
                  placeholder="07X-xxx-xxxx"
                  required

                  onChange={this.ChangeHandler}
                />
                <br></br>
                <label className="form-label">
                   (Enter Your ID Number)
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="NIC"
                  placeholder="xxxx-xxxx-xxxx"
                  required

                  onChange={this.ChangeHandler}
                />

                <label className="form-label">
                   (Enter Your Passport Number)
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="passportnumber"
                  placeholder="xxxx-xxxx-xxxx"
                  required
                  onChange={this.ChangeHandler}
                />

                <br></br>
                <label className="form-label">
                   (Enter Your Agency Name){" "}
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="agencyname"

                  placeholder="Agency Name"
                  required
                  onChange={this.ChangeHandler}
                />Jobname

                <br></br>
                <label className="form-label">
                   (Enter Your Job Name ){" "}
                </label>
                <input
                  className="form-control"
                  type="text"
                  name="Jobname"

                  placeholder="Job Name"
                  required
                  onChange={this.ChangeHandler}
                />

                <br />
                <label className="form-label">
                   (Enter Your E-mail Address)
                </label>
                <input
                  className="form-control"
                  name="Email"
                  type="text"
                  placeholder="_________@example.com"
                  required

                  onChange={this.ChangeHandler}
                />
              </div>
              <div className="col-md-6">
                <label className="form-label">
                   (Enter Your Address){" "}
                </label>
                <textarea
                  className="form-control"
                  cols="30"
                  rows="5"
                  required
                  name="Address"

                  onChange={this.ChangeHandler}
                />
                <br />
                <label className="form-label">
                   (Enter Your Complaint){" "}
                </label>
                <br />
                <textarea
                  className="form-control"
                  name="Complaint"
                  cols="100"
                  rows="9"
                  required
                  onChange={this.ChangeHandler}
                />
                <br />
                <h5>
                  submit
                </h5>
                <button type="submit" className="btn btn-primary me-1">
                  Submit Complaintd
                </button>
              </div>
            </div>

            <br />
            <br />
          </form>
        </div>
      </div>
    );
  }
}
